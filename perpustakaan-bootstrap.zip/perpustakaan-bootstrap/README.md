# Aplikasi Perpustakaan Digital Sekolah (Bootstrap 5)

Versi sesuai modul UKK SMK RPL: Login Admin, Dashboard, Logout.

## Struktur
```
perpustakaan/
├── koneksi.php
├── login-admin.php
├── css/        <- isi dengan folder css dari Bootstrap
├── js/         <- isi dengan folder js dari Bootstrap
├── admin/
│   ├── dashboard.php
│   └── logout.php
└── database/
    └── perpustakaan.sql
```

## Cara Menjalankan
1. Download Bootstrap: https://getbootstrap.com/docs/5.3/getting-started/download/
2. Ekstrak zip Bootstrap, salin isi folder `css` dan `js` ke folder `css` dan `js` proyek ini (ganti file placeholder).
3. Salin folder `perpustakaan` ke `C:\xampp\htdocs\`.
4. Start Apache dan MySQL, lalu di phpMyAdmin tab **Import** pilih `database/perpustakaan.sql`.
5. Buka `http://localhost/perpustakaan/login-admin.php` (username `admin`, password `admin`).
