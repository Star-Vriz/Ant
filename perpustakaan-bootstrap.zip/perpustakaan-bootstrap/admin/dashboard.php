<?php
session_start();
if (empty($_SESSION['id_admin'])) {
    header("Location:../login-admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Aplikasi Perpustakaan Sekolah Digital</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-3">
        <h4>Halaman Admin - Aplikasi Perpustakaan Sekolah Digital</h4>
        <!-- membuat menu -->
        <a href="dashboard.php" class="btn btn-success text-white">Dashboard</a>
        <a href="?halaman=data_buku" class="btn btn-primary text-white">Buku</a>
        <a href="?halaman=data_anggota" class="btn btn-info text-white">Anggota</a>
        <a href="?halaman=data_peminjaman" class="btn btn-warning text-white">Peminjaman</a>
        <a href="logout.php" class="btn btn-danger text-white">Logout</a>
        <!-- membuat isi halaman secara otomatis -->
        <div class="card p-3 mt-3">
            <?php
            //mengambil parameter
            $halaman = isset($_GET['halaman']) ? basename($_GET['halaman']) : '';
            //cari file ada atau tidak
            if ($halaman != '' && file_exists($halaman . ".php")) {
                //jika ada panggil file yang namanya sama dengan GET
                include $halaman . ".php";
            } else { //jika file tidak ada
            ?>
                <h4>Selamat Datang <?= $_SESSION['nama_admin']; ?> 👋</h4>
                <p class="text-justify text-muted">
                    Aplikasi Perpustakaan Sekolah Digital merupakan sistem berbasis web
                    yang dirancang untuk membantu pengelolaan data buku, peminjaman,
                    dan pengembalian secara lebih mudah, cepat, dan terorganisir.
                </p>
            <?php } ?>
        </div>
    </div>
</body>

</html>
